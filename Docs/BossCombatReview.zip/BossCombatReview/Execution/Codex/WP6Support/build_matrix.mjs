// WP6 single authoring/verification builder. Reads source only, emits JSON to stdout;
// final Markdown/CSV written by reviewed apply_patch, never modifies source/control docs.
import fs from 'node:fs/promises';
import { Workbook } from '@oai/artifact-tool';
const source = await fs.readFile(new URL('../D03_RECONCILIATION_PROGRESS.md', import.meta.url), 'utf8');
const rows = source.split(/\r?\n/).filter(x => /^\| \*\*BOSS-/.test(x)).map(x => {
  const c = x.split('|').slice(1,-1).map(s=>s.trim());
  const m = c[0].match(/\*\*(BOSS-([A-Z]+)-(\d+))\*\*\s*(.*)/);
  return {id:m[1],family:m[2],n:Number(m[3]),clause:m[4],status:c[1],data:c[3],validation:c[4]};
});
// Every slot is deliberate and row-specific: definition field, shared unit, delivery phase,
// baseline witness. New Ref.<ID> assertions are PLANNED, not existing/passed tests.
const map = {
AWR:[
['Encounter.TargetPolicy.Validity','RPGTargetValidator','P6','pie_attack_rules'],
['Boss.ObservationProfile.Snapshot','RPGCombatObservationService','P6','new context-snapshot driver'],
['Move.Eligibility.DistanceConvention','RPGTargetGeometry','P6','pie_close_attacks'],
['Move.Eligibility.YawCone','RPGTargetGeometry','P6','pie_close_attacks'],
['Move.Eligibility.HeightInterval','RPGTargetGeometry','P6','pie_a4_low_sweep'],
['Move.ReactionTrigger.ObservedActivity','RPGCombatObservationService','P6','pie_a5_heal_punish'],
['Boss.ObservationProfile.LastSeenExpiry','RPGCombatObservationService','P6','new LOS-memory driver'],
['Boss.AdaptationProfile','RPGPatternMemoryService','P6','D09_AWR-008 tests']],
SEL:[
['Move.Selection.LegalGate','RPGCombatActionRuntime','P2','pie_attack_rules'],
['Move.Eligibility','RPGEligibilityFilter','P6','new candidate-filter driver'],
['Move.Variants.RequiredDependencies','RPGEligibilityFilter','P6','new missing-dependency driver'],
['Move.Selection.UtilityTerms','RPGUtilitySelector','P6','D09_SEL-004 tests'],
['Boss.Selector.Seed/TiePolicy','RPGUtilitySelector','P6','new seeded-decision replay'],
['Move.Cooldown.Owner/ConsumePolicy','RPGCombatResources','P2','pie_a5_heal_punish'],
['Boss.Selector.HistoryProfile','RPGUtilitySelector','P6','new exact/family decay driver'],
['Boss.EmptyPoolPolicy','RPGDecisionFallbackController','P6','D09_SEL-008 tests'],
['Move.ReactionTrigger.Delay/Budget','RPGCombatActionRuntime','P6','pie_a5_heal_punish'],
['Boss.Selector.TracePolicy','RPGDecisionTrace','P6','new candidate/score trace audit']],
EXE:[
['Boss.ConflictPolicy/AuthorityProfile','RPGCombatActionRuntime','P2','pie_attack_rules'],
['Move.Activation.BindingId','RPGCombatActionRuntime','P2','new pre-play token driver'],
['Move.Activation.FailureRefund','RPGCombatResources','P2','new rejected-play driver'],
['Move.Variants/Encounter.Generation','RPGCombatActionRuntime','P2','pie_phase_reset'],
['Boss.ConflictPolicy','RPGCombatActionRuntime','P2','pie_transition_rules'],
['Move.Safety.TerminalPolicy','RPGCombatResources','P2','pie_player_death_reset'],
['Move.Safety.MaxRealDuration','RPGCombatActionRuntime','P2','new missing-notify watchdog'],
['Move.EarliestNextSelection','RPGCombatActionRuntime','P2','new finalization/unlock driver']],
COM:[
['Move.Followups.TargetMoveIds','RPGComboGraph','P5','pie_close_attacks'],
['Move.Followups.GateWindow','RPGComboGraph','P5','pie_close_attacks'],
['Move.Followups.Eligibility','RPGComboGraph','P5','new branch context driver'],
['Move.Followups.ContactPolicy','RPGComboGraph','P5','new hit/guard/whiff branch driver'],
['Move.Followups.GateId/Consume','RPGComboGraph','P2','new duplicate-branch driver'],
['Move.Followups.Depth/TimeBudget','RPGComboGraph','P5','new combo budget driver'],
['Move.Followups.DefaultRecovery','RPGComboGraph','P5','new rejected-branch recovery']],
ANM:[
['Move.Variants.TimelineSource','RPGCombatTimelineExecutor','P2','pie_authored_close_clips'],
['Move.Presentation.Telegraph','RPGCombatCueRuntime','P1','CAP01/CAP02/CAP03/CAP04 plus cue capture'],
['Move.Variants.HoldSpec','RPGHoldTraversal','P5','D09_ANM-003 tests'],
['Move.Tracking.Windows/TurnCaps','RPGMotionOwnershipController','P5','pie_close_attacks'],
['Move.Motion.Owner/Handoffs','RPGMotionOwnershipController','P4','new motion-ownership driver'],
['Move.Motion.WarpSpec','RPGWarpExecutor','P4','D09_ANM-006 tests'],
['Move.Safety.TerminalPolicy','RPGCombatResources','P2','pie_player_death_reset'],
['Move.Variants.Provenance/MoveCard','RPGMoveDefinitionValidator','P8','move-card completeness + all variant captures']],
HIT:[
['Move.Effects.ShapeSpec.VisibleMap','RPGCombatGeometry','P4','pie_trace_audit + CAP02'],
['Weapon.QueryProfile.PreviousSamples','RPGWeaponSweepExecutor','P4','pie_trace_audit'],
['Weapon.QueryProfile.InteriorSamples','RPGWeaponSweepExecutor','P4','new blade-interior contact driver'],
['Weapon.QueryProfile.SampleErrorBound','RPGWeaponSweepExecutor','P4','new angular/linear hitch sweep'],
['Move.Effects.ShapeSpec.Filters','RPGCombatGeometry','P3','pie_trace_audit'],
['Move.Effects.HitGroupId','RPGHitLedger','P3','new multibody dedupe driver'],
['Move.Effects.HitPolicy','RPGHitLedger','P3','new per-window/periodic/impact driver'],
['Move.Effects.DefensePolicy','RPGDamageResolver','P3','pie_damage_path'],
['Move.Effects.DefensePolicy.Iframes','RPGDamageResolver','P3','pie_iframes'],
['Move.Effects.DirectSplashPolicy','RPGDamageResolver','P3','pie_leap_wave'],
['Move.Effects.RadialWaveSpec','RPGRadialWaveExecutor','P4','pie_leap_wave'],
['Move.Effects.PairedGrabSpec','RPGPairedActionExecutor','P5','D09_HIT-012 tests']],
MOV:[
['Boss.MovementProfile.DistanceBands','RPGCombatPositionPlanner','P6','new distance-band driver'],
['Boss.MovementProfile.GoalScoring','RPGCombatPositionPlanner','P6','new reachable-position driver'],
['Boss.MovementProfile.CommitBudget','RPGCombatPositionPlanner','P6','new movement hysteresis driver'],
['Move.Motion.Path/LandingPolicy','RPGMotionOwnershipController','P4','new wall/ledge/landing driver'],
['Encounter.ArenaValidity/Reacquire','RPGDecisionFallbackController','P6','D09_SEL-008 tests'],
['Encounter.ArenaFit/DefenseClearance','RPGCombatPositionPlanner','P8','new arena-grid cue/defense audit']],
PAC:[
['Move.Variants.SemanticSegments','RPGCombatTimelineExecutor','P5','pie_authored_close_clips'],
['Boss.PressureProfile','RPGPressureBudget','P5','new burst/reset driver'],
['Move.Recovery.PunishPolicy','RPGPressureBudget','P5','new commitment punish trials'],
['Move.Presentation.BranchCue','RPGCombatCueRuntime','P1','new branch-readable capture'],
['Build.Equipment/Move.Recovery','RPGPunishAnalyzer','P5','pie_builds + new per-build punish trials'],
['Boss.MovementProfile.NeutralPolicy','RPGCombatPositionPlanner','P6','new purposeful-neutral driver']],
DEF:[
['Boss.Stats/Posture/ConflictPolicy','RPGDamageResolver','P3','pie_posture_hits'],
['Boss.Posture.RegenDelay/Rate/Reset','RPGPostureRuntime','P3','pie_posture_hits + posture_regen'],
['Boss.Stagger/CriticalPolicy','RPGPairedActionExecutor','P3','pie_riposte_exec/phase_reset'],
['Move.DefensePolicy.ArmorWindows','RPGDefenseActionExecutor','P3','pie_hyperarmor'],
['Boss.DefenseProfile','RPGDefenseActionExecutor','P3 mechanism; P6 decision','D09_DEF-005 tests']],
PHS:[
['Boss.Phases[]','RPGPhaseRuntime','P7','pie_phase_reset'],
['Boss.Phases.TransitionPolicy','RPGPhaseRuntime','P7','pie_transition_rules'],
['Encounter.Generation/Boss.PhaseEntry','RPGPhaseRuntime','P7','pie_phase_reset'],
['Move.ReactionTrigger/ProjectileSpec','RPGReactionRuntime','P6','pie_a5_heal_punish'],
['Boss.AntiCheeseProfile','RPGCombatPositionPlanner','P7','new kite/rear/terrain/guard trials']],
QA:[
['Presentation.DebugOverlayProfile','RPGCombatDebugOverlay','P8','pie_debug_overlay + field completeness'],
['Catalog.Diagnostics.EventSchema','RPGCombatEventTrace','P2','new action/contact causal trace audit'],
['Encounter.ReproductionProfile','RPGDecisionTrace','P8','seed/setup replay suite'],
['Move.Variants.TimeDomainPolicy','RPGCombatTimelineExecutor','P8','all-move30/60/120/time-scale suite'],
['Catalog.RuntimeBudgetProfile','RPGCombatBudgetMonitor','P8','packaged benchmark + query budget trace'],
['Presentation.CameraProfile','RPGCameraRig','P8','pie_camera_scenarios + threat captures'],
['Presentation.AccessibilityProfile','RPGCombatCueRuntime','P8','new reduced-FX/non-color cue capture'],
['Catalog.AuthorityProfile','RPGCombatAuthorityGateway','P8 (cross-cutting DD1/P2-P7)','D09_QA-008 listen/dedicated tests']]
};
const headers=['ID','Requirement clause','Owning definition field (D02)','Shared runtime component','Delivery phase','Implementation unit (proposed unless existing)','Proving test and assertion','Evidence needed for IMPLEMENTED','Status today (D03 provisional)'];
const plain = s => s.replace(/\*\*/g,'').replace(/\[([^\]]+)\]\([^)]*\)/g,'$1');
const values=rows.map(r=>{
  const entry=map[r.family]?.[r.n-1]; if(!entry) throw Error('No explicit mapping for '+r.id);
  const [field,unit,phase,witness]=entry;
  const overrides={
    'BOSS-QA-008':'Server-only decision/HP/posture/cooldown/phase; replicated attack ID/start time/section/target/phase; listen/dedicated two clients at80/150ms RTT and packet loss; stale/duplicate/unowned writes rejected',
    'BOSS-HIT-012':'Boss captures only eligible target; one impact; safe control/collision/motion release on death/reset/interrupt/disconnect/timeout at every stage',
    'BOSS-ANM-003':'Two bounded holds chosen before commit; no future-input read; hitch/rate/interrupt cannot extend max or duplicate release',
    'BOSS-AWR-008':'Observable repeated patterns alter capped preference after delay, then decay; target/reset isolation; hard eligibility unchanged; debug-off capture ties observable cue timing to changed action, readable failure and punish opportunity',
    'BOSS-SEL-004':'Controlled contexts log comparable normalized range/angle/opportunity/spacing/phase/variety terms; actual selected variant matches accepted winner',
    'BOSS-SEL-008':'All legal moves unavailable causes bounded wait/reposition/reacquire, finite queries/progress deadline; no illegal attack or infinite retry',
    'BOSS-ANM-006':'Actual early root-motion warp within distance/yaw/path caps, no postcommit homing; wall/ledge/abort restores single motion owner',
    'BOSS-DEF-005':'Guard/parry/dodge each succeed legally and fail outside angle/window/resource/cooldown; readable startup and measured punish recovery; server outcome; P3 proves defense states/resolver outcomes; P6 proves delayed, budgeted observable-cue AI choices'
  };
  const assertion=overrides[r.id] ?? plain(r.validation).replace(/; Boss01 \+ canary[\s\S]*$/,'').replace(/IMPLEMENTED[\s\S]*$/,'').trim();
  const evidence='Complete relevant active/fallback/abort/phase paths; source/automation for structural clauses, actual runtime logs for behavior, capture for perceptual clauses; pin source/definition/asset/binary hashes; Boss01 and data-only canary. '+(r.id==='BOSS-QA-008'?'Server AND both client identity/time/state logs. ':'')+assertion;
  const status=r.status.split('->').at(-1).split(';')[0].trim();
  return [r.id,r.clause,field,unit,phase,'Source/OneBossFight/Player/'+unit+'.h/.cpp (shared); Tests/RPGReferenceRequirementsTests.cpp::'+r.id.replaceAll('-','_'),witness+'; NEW Ref.'+r.id+': '+assertion,evidence,status];
});
if(rows.length!==83||new Set(rows.map(r=>r.id)).size!==83) throw Error('D03 uniqueness/count mismatch');
const workbook=Workbook.create(); const sheet=workbook.worksheets.add('Implementation');
sheet.getRange('A1:I84').values=[headers,...values]; workbook.recalculate();
const roundTrip=sheet.getRange('A1:I84').values;
if(JSON.stringify(roundTrip)!==JSON.stringify([headers,...values])) throw Error('Artifact range roundtrip altered source rows');
console.log(JSON.stringify({headers:roundTrip[0],rows:roundTrip.slice(1),sourceRows:rows.length,unique:new Set(values.map(r=>r[0])).size,artifactRoundTrip:true}));
