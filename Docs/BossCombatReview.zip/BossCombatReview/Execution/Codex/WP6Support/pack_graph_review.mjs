// Read-only source exports. Graph-qualified nodes, pins and edges, no editor.
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
const dir='Docs/BossCombatReview/Execution/Claude/Evidence/exports';
const all=[];
for(const file of (await fs.readdir(dir)).filter(n=>/^PR[23]_/.test(n)&&/\.t3d$/.test(n)&&!/_CDO_/.test(n))){
 const text=await fs.readFile(dir+'/'+file,'utf8'),lines=text.split(/\r?\n/),stack=[],nodes=new Map();
 for(let i=0;i<lines.length;i++){
  const s=lines[i].trim(),begin=s.match(/^Begin Object(?: Class=(\S+))? Name="([^"]+)"/);
  if(begin){stack.push({name:begin[2],cls:begin[1]||''});continue;}
  if(/^End Object/.test(s)){stack.pop();continue;}
  if(!stack.length||!/^K2Node_|^EdGraphNode_/.test(stack.at(-1).name))continue;
  const key=stack.map(x=>x.name).join('/');let n=nodes.get(key);
  if(!n){n={key,line:i+1,members:[],pins:[],refs:[]};nodes.set(key,n);}
  if(/^(FunctionReference|EventReference|VariableReference|CustomFunctionName|NodeComment|TargetType)=/.test(s)){
   n.refs.push({line:i+1,text:s});for(const m of s.matchAll(/MemberName="([^"]+)"/g))n.members.push(m[1]);
  }
  if(s.startsWith('CustomProperties Pin')){
   const get=re=>s.match(re)?.[1];const linked=get(/LinkedTo=\(([^)]*)\)/)||'';
   n.pins.push({line:i+1,id:get(/PinId=([A-Fa-f0-9]+)/),name:get(/PinName="([^"]*)"/),direction:get(/Direction="([^"]*)"/)||'EGPD_Input',category:get(/PinCategory="([^"]*)"/),value:get(/DefaultValue="((?:[^"\\]|\\.)*)"/),object:get(/DefaultObject="([^"]*)"/),links:[...linked.matchAll(/(\S+) ([A-Fa-f0-9]{32})/g)].map(m=>({name:m[1],id:m[2]}))});
  }
 }
 const byPin=new Map();for(const n of nodes.values())for(const p of n.pins){const g=n.key.split('/').slice(0,-1).join('/');byPin.set(g+'/'+p.id,{n,p});}
 let edges=0,unresolved=0;for(const n of nodes.values())for(const p of n.pins)if(p.direction==='EGPD_Output')for(const l of p.links){edges++;const g=n.key.split('/').slice(0,-1).join('/'),t=byPin.get(g+'/'+l.id);if(!t)unresolved++;l.target=t?`${t.n.key}.${t.p.name}`:'UNRESOLVED';l.targetMembers=t?.n.members;}
 all.push({file,sha256:crypto.createHash('sha256').update(text).digest('hex'),nodeCount:nodes.size,edges,unresolved,nodes:[...nodes.values()]});
}
await fs.writeFile('Docs/BossCombatReview/Execution/Codex/WP6Support/pack_graphs.json',JSON.stringify(all,null,2));
const requested=process.argv[2]||'Grab';
const pattern=new RegExp(process.argv[3]||'GrabMontage|AttackMontages|Start Sync|EndAbility|Sync|SetGrabData','i');
for(const a of all.filter(a=>a.file.includes(requested))){console.log(`FILE ${a.file} nodes=${a.nodeCount} edges=${a.edges} unresolved=${a.unresolved}`);for(const n of a.nodes){if(n.members.some(m=>pattern.test(m))&&!n.key.includes('_MERGED/'))console.log(`${n.line} ${n.key} : ${n.members.join(' / ')}\n`+n.pins.filter(p=>p.direction==='EGPD_Output'||p.value||p.object).map(p=>`  ${p.line} ${p.name}=${p.value||p.object||''} ${p.links.map(l=>`${l.target} [${l.targetMembers?.join(',')}]`).join('; ')}`).join('\n'));}}
