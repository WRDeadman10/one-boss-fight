"""Read-only AG16 audit; never invokes its file-writing main or modifies AG files."""
import hashlib
import json
from pathlib import Path

root = Path(__file__).resolve().parents[5]
ag = root / 'Docs/BossCombatReview/Execution/Antigravity/Evidence'
source = ag / 'timeline_reference.py'
ns = {'__name__': 'codex_read_only_review', '__file__': str(source)}
exec(compile(source.read_text(encoding='utf-8'), str(source), 'exec'), ns)
c = ns['TimelineCompilerReference']()
c.load_inputs()
ns['run_self_tests'](c)
data = json.loads((ag / 'timeline_expected.json').read_text(encoding='utf-8'))
assert c.input_hashes == data['provenance']['input_hashes'], 'stale input manifest'
parsed = c.parse_montage_notifies_txt()
for name, montage in parsed.items():
    assert c.compile_montage(montage) == data['montages'][name], 'oracle drift ' + name
a2 = data['montages']['GS_ChargedAttack_Montage']
assert [(w['begin_s'], w['end_s']) for w in a2['windows']] == [(0., 3.4000000953674316), (1.567, 1.760), (1.925, 2.104)]
nan_result = c.evaluate_crossing(a2, float('nan'), .5)
loop_result = c.evaluate_crossing(a2, .1, .2, traversal='ForwardLoop', prev_loop_ordinal=0, loop_ordinal=1)
print(json.dumps({'inputHashes': len(c.input_hashes), 'matchedMontages': len(parsed),
                  'rawExportSHA256': c.input_hashes['montage_notifies_2026-10-25.txt'],
                  'expectedJSON_SHA256': hashlib.sha256((ag / 'timeline_expected.json').read_bytes()).hexdigest(),
                  'NaN_evaluation_status': nan_result['status'],
                  'ForwardLoop_curr_ge_prev_status': loop_result['status'],
                  'ForwardLoop_crossings': loop_result['crossings']}, indent=2))
