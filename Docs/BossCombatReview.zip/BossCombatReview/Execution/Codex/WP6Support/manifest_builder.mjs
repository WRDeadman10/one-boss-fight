// X-T4: read-only native/export scan; author CSV through Artifact Tool.
import fs from 'node:fs/promises';
import path from 'node:path';
import crypto from 'node:crypto';
import {Workbook} from '@oai/artifact-tool';
const root=path.resolve(new URL('../../../../../../',import.meta.url).pathname.replace(/^\/([A-Za-z]:)/,'$1'));
// Resolve from the working directory, asserted to be the intended workspace.
const project=process.cwd();
if(!project.toLowerCase().endsWith('onebossfight')) throw Error('Run from OneBossFight root');
const out='Docs/BossCombatReview/Execution/Codex';
if(process.argv.includes('--native-view')){
 const source=await Workbook.fromCSV(await fs.readFile(out+'/WP13_BOSS01_FIELD_MANIFEST.csv','utf8'),{sheetName:'Source'});
 const all=source.worksheets.getItem('Source').getUsedRange().values;
 const filtered=all.slice(1).filter(r=>r[6]!=='SERIALIZED_EXPORT_NOT_RUNTIME').sort((a,b)=>a[1].localeCompare(b[1])||Number(a[2])-Number(b[2]));
 const wb=Workbook.create(),s=wb.worksheets.add('Native fields');s.getRangeByIndexes(0,0,filtered.length+1,12).values=[all[0],...filtered];wb.recalculate();
 const output=s.getUsedRange().values.map(r=>r.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';
 await fs.writeFile(out+'/WP13_BOSS01_NATIVE_FIELDS.csv',output);
 const groups={};for(const r of filtered){groups[r[1]]??={HYDRATABLE_NOW:0,NEEDS_SEAM:0,NEEDS_EDITOR:0};groups[r[1]][r[9]]++;}
 await fs.writeFile(out+'/WP6Support/native_field_counts.json',JSON.stringify(groups,null,2));
 const counts=Object.fromEntries(['HYDRATABLE_NOW','NEEDS_SEAM','NEEDS_EDITOR'].map(c=>[c,filtered.filter(r=>r[9]===c).length]));
 const reread=await Workbook.fromCSV(output,{sheetName:'Verify'});
 if(reread.worksheets.getItem('Verify').getUsedRange().values.length!==1535||filtered.length!==1534)throw Error('native row count');
 console.log(JSON.stringify({rows:filtered.length,counts,files:Object.keys(groups).length,sha256:crypto.createHash('sha256').update(output).digest('hex')}));
 process.exit(0);
}
const pdir='Source/OneBossFight/Player';
const nativeNames=(await fs.readdir(pdir)).filter(n=>/^RPGBoss|^RPGAttackTracker|^RPGPlayerMovesSubsystem|^RPGTelegraphRules/.test(n)&&/\.(h|cpp)$/.test(n));
const native=nativeNames.map(n=>pdir+'/'+n).concat(['Source/OneBossFight/UI/RPGBossHud.h','Source/OneBossFight/UI/RPGBossHud.cpp']);
const edir='Docs/BossCombatReview/Execution/Claude/Evidence/exports';
// All serialized property records of shipped-boss CDOs/info/style/BT, and PR2/3 CDOs,
// styles, attack data and montage/sequence metadata. Blueprint graphs handled separately X-T5.
const packNames=(await fs.readdir(edir)).filter(n=>/\.t3d$/.test(n)&&(
 /^CDO_(BP_ExampleGreatSwordBoss|GA_GS_Boss_|GA_LeapAttack)/.test(n)||
 /^(ExampleGreatSwordBoss_info|ExampleGreatSwordBossCombatStyle|BT_ExampleBoss)\.t3d$/.test(n)||
 /^PR[23]_/.test(n)&&(/_CDO_/.test(n)||/CombatStyle|DefaultGrabAttackData|Montage|PR3_Dodge_|PR3_Deflect_|PR3_ExampleGreatSwordBoss\.t3d/.test(n))));
const rows=[], pins=[], covered=new Set();
const headers=['RecordId','Source','Line','ObjectOrFunction','FieldOrRole','ValueExpression','ValueKind','DefinitionField','Consumer','Class','ParityCheck','SourceSHA256'];
const exact={
 GateRadius:'Encounter.Activation.Radius',BossMaxHealth:'Boss.Stats.MaxHealth',StartupEnforceSeconds:'Encounter.StartupHealthEnforcementSeconds',
 bTestFreeze:'Encounter.TestPolicy.Freeze',bResetOnPlayerRespawn:'Encounter.Lifecycle.ResetOnPlayerRespawn',
 PhaseTwoHealthFraction:'Boss.Phases[Phase2].HealthThreshold',MovementScale:'Boss.Phases[Phase2].MovementScale',AttackRateScale:'Boss.Phases[Phase2].AttackRateScale',DamageScale:'Boss.Phases[Phase2].DamageScale',
 TransitionSeconds:'Boss.Phases[Phase2].Transition.Duration',RoarClip:'Boss.Phases[Phase2].Transition.Playback',TransitionMontage:'Boss.Phases[Phase2].Transition.FallbackMontage',ImmunityEffect:'Boss.Phases[Phase2].Transition.ImmunityEffect',
 LeapAbilityTag:'Boss.Phases[Phase2].UnlockTags',bLockLeapUntilPhaseTwo:'Boss.Phases[Phase2].Eligibility.LeapLock',
 StaggerSeconds:'Boss.Stagger.Duration',FreezeAtPosition:'Boss.Stagger.FallFreezePosition',CriticalMultiplier:'Boss.Stagger.CriticalMultiplier',
 RiposteRange:'Boss.Riposte.Range',RiposteConeDegrees:'Boss.Riposte.TargetConeDegrees',RiposteFacingDegrees:'Boss.Riposte.PlayerFacingDegrees',RiposteImpactSeconds:'Boss.Riposte.ImpactSeconds',RiposteBaseDamage:'Boss.Riposte.BaseDamage',
 RiposteAlignSeconds:'Boss.Riposte.AlignSeconds',RipostePlayerStartGap:'Boss.Riposte.StartGap',RiposteArmSeconds:'Boss.Riposte.ArmSeconds',
 DormantClip:'Boss.Lifecycle.Dormant.Playback',WakeClip:'Boss.Lifecycle.Wake.Playback',
 BossName:'Presentation.HUD.BossName',VictoryText:'Presentation.HUD.VictoryText',
};
function group(file){
 if(/Encounter/.test(file))return'Encounter'; if(/Phases/.test(file))return'Boss.Phases[Phase2]';
 if(/Stagger/.test(file))return'Boss.StaggerAndRiposte'; if(/LowSweep/.test(file))return'Move[A4].Effects.PlanarSweep';
 if(/HealPunish/.test(file))return'Move[A5].ReactionAndProjectile'; if(/Javelin/.test(file))return'Move[A5].Effects.Projectile';
 if(/Shockwave/.test(file))return'Move[A6].Effects.RadialWave'; if(/DormantWake/.test(file))return'Boss.Lifecycle';
 if(/AttackTracker/.test(file))return'Move.Variants.ExplicitCompatibility'; if(/BossHud/.test(file))return'Presentation.HUD';
 if(/Look/.test(file))return'Presentation.Look'; if(/Death|Remains/.test(file))return'Boss.Lifecycle.Death';
 if(/Posture/.test(file))return'Boss.Stats.Posture'; if(/Bleed/.test(file))return'Boss.Stats.Bleed';
 if(/PlayerMovesSubsystem/.test(file))return'Encounter.ParticipantAttachment';return'Boss.Compatibility';
}
function parity(file){
 if(/Stagger/.test(file))return'pie_riposte + pie_riposte_exec + pie_transition_rules';
 if(/Phases/.test(file))return'pie_phase_reset + pie_transition_rules';
 if(/HealPunish|Javelin/.test(file))return'pie_a5_heal_punish + pie_damage_path; compare spawn/rate/damage';
 if(/LowSweep/.test(file))return'pie_a4_low_sweep; E008 query/visible correspondence separately';
 if(/Shockwave/.test(file))return'pie_leap_wave; direct-hit/wave exclusivity';
 if(/AttackTracker|CloseClip/.test(file))return'pie_attack_rules + pie_authored_close_clips + per-variant tracker samples';
 if(/Dormant|Encounter/.test(file))return'pie_dormant_wake (WakeClip0 and1) + pie_player_death_reset';
 if(/Hud/.test(file))return'pie_boss_hud + pie_build_hud + debug-off screenshot';
 return'full Boss01 gate + field readback before/after hydration';
}
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
function add(file,line,obj,field,value,kind,definition,consumer,cls,check,hash){
 const id=`${file}:${line}:${field}`;
 if(covered.has(id))throw Error('duplicate '+id);covered.add(id);
 rows.push([`F${String(rows.length+1).padStart(5,'0')}`,file,line,obj,field,value,kind,definition,consumer,cls,check,hash]);
}
// Strip comments without losing source-line alignment or literals inside strings.
function strip(src){let block=false;return src.split(/\r?\n/).map(line=>{let out='',q=false,esc=false;for(let i=0;i<line.length;i++){const c=line[i],n=line[i+1];if(block){if(c==='*'&&n==='/'){block=false;i++;}continue;}if(!q&&c==='/'&&n==='*'){block=true;i++;continue;}if(!q&&c==='/'&&n==='/')break;out+=c;if(c==='"'&&!esc)q=!q;esc=c==='\\'&&!esc;}return out;});}
for(const file of native.sort()){
 const bytes=await fs.readFile(file),hash=sha(bytes),lines=strip(bytes.toString('utf8'));pins.push({file,hash,lines:lines.length});
 let access='private', pending=null,fn=path.basename(file),properties=0;
 const consumed=new Set();
 for(let i=0;i<lines.length;i++){
  const s=lines[i].trim();
  if(/^(public|private|protected):/.test(s))access=s.split(':')[0];
  if(/UPROPERTY\(/.test(s)){pending={edit:/EditAnywhere|EditDefaultsOnly/.test(s),access};continue;}
  if(pending&&s&&!s.startsWith('//')){
   const m=s.match(/^([\w:<>, *]+?)\s+(\w+)\s*(?:=\s*(.*?))?;/);
   if(m){const [,type,name,initial]=m;properties++;
    const asset=/SoftObject|SoftClass/.test(type),cls=pending.edit&&pending.access==='public'&&!asset?'HYDRATABLE_NOW':asset?'NEEDS_EDITOR':'NEEDS_SEAM';
    add(file,i+1,path.basename(file),name,initial||'(uninitialized here; constructor/serialized override must be read)',asset?'ASSET_REFERENCE_DEFAULT':'CXX_PROPERTY_DEFAULT',exact[name]||`${group(file)}.${name}`,`${path.basename(file)} public/native consumers; inspect uses by symbol`,cls,parity(file)+'; assert effective instance value, not CDO assumption',hash);consumed.add(i);pending=null;continue;
   }pending=null;
  }
  const f=s.match(/(?:\w+::)(\w+)\s*\(/);if(f)fn=f[1];
  if(!s||/^#|^UFUNCTION|^UCLASS|^GENERATED_BODY/.test(s)||consumed.has(i))continue;
  if(/(?:"(?:[^"\\]|\\.)*"|(?<![\w])(?:\d+(?:\.\d*)?|\.\d+)[fFuUlL]*\b|\btrue\b|\bfalse\b)/.test(s)){
   let role='IMPLEMENTATION_LITERAL',kind='CODE_EXPRESSION',def=`${group(file)}.REVIEW_REQUIRED[${path.basename(file)}:${i+1}]`;
   if(/UE_LOG|Printf|OutWhy|Reason|AddEvent|return TEXT/.test(s))role='DIAGNOSTIC_OR_TEXT';
   if(/TAutoConsoleVariable|CVar/.test(s))role='STARTUP_OR_DEBUG_POLICY';
   if(/TickInterval/.test(s))role='SCHEDULING_CONSTANT';
   if(/TEXT\("\/Game/.test(s)){role='ASSET_BINDING';kind='ASSET_REFERENCE_DEFAULT';}
   const m=s.match(/\b(A[1-6]|A3[ab])\.(\w+)\s*=/);if(m){role='MOVE_TIMING_FIELD';def=`Move[${m[1]}].Variants.ExplicitCompatibility.${m[2]}`;}
   if(/^AddClose\(/.test(s)){role='MOVE_TIMING_ROW';def='Move.CloseVariants.{MoveId,Montage,Fallback,Path,Commit,ActiveStart,ActiveEnd,Recovery,Branch,Authored}';}
   // Runtime seeds and sentinels stay visible, not silently promoted to authorable numbers.
   if(/^(?:float|double|int32|bool|FVector|FName)\s+\w+\s*=/.test(s)&&/\.h$/.test(file))role='PRIVATE_STATE_SEED_OR_CONSTANT';
   add(file,i+1,fn,role,s,kind,def,path.basename(file)+'::'+fn,kind==='ASSET_REFERENCE_DEFAULT'?'NEEDS_EDITOR':'NEEDS_SEAM',parity(file)+'; classify invariant vs content before migration',hash);
  }
 }
}
for(const name of packNames.sort()){
 const file=edir+'/'+name,bytes=await fs.readFile(file),hash=sha(bytes),lines=bytes.toString('utf8').split(/\r?\n/);pins.push({file,hash,lines:lines.length});
 const stack=[];
 for(let i=0;i<lines.length;i++){
  const s=lines[i].trim();if(/^Begin Object/.test(s)){stack.push((s.match(/Name="([^"]+)"/)||[])[1]||'?');continue;}if(/^End Object/.test(s)){stack.pop();continue;}
  const m=s.match(/^([^=]+)=(.*)$/);if(!m)continue;
  // Metadata geometry and serialized tunables all retained; editor graph pin export text is not in this corpus.
  add(file,i+1,stack.join('/'),m[1],m[2],'SERIALIZED_EXPORT_NOT_RUNTIME',
   /BT_/.test(name)?'Move.Selection.PackCompatibility.'+m[1]:/Style/.test(name)?'Boss.PackBindings.Style.'+m[1]:'Boss.PackBindings.Compatibility.'+m[1],
   name.replace('.t3d','')+' (actual live actor/ability readback required)','NEEDS_EDITOR','compare full object identity + effective runtime value; export is not instance proof',hash);
 }
}
const wb=Workbook.create(),sheet=wb.worksheets.add('Boss01 fields'),matrix=[headers,...rows];
sheet.getRangeByIndexes(0,0,matrix.length,headers.length).values=matrix;
sheet.showGridLines=false;sheet.freezePanes.freezeRows(1);
sheet.getRange('A1:L1').format={fill:'#263B55',font:{name:'Arial',bold:true,color:'#FFFFFF'}};
sheet.getRange('A1:A8').format.columnWidth=14;
sheet.getRange('B1:B8').format.columnWidth=90;
sheet.getRange('C1:C8').format.columnWidth=8;
sheet.getRange('D1:D8').format.columnWidth=38;
sheet.getRange('E1:E8').format.columnWidth=40;
sheet.getRange('F1:F8').format.columnWidth=70;
sheet.getRange('A1:E8').format.wrapText=true;
sheet.getRange('A1:E8').format.rowHeight=35;
sheet.getRange('C2:C'+matrix.length).setNumberFormat('0');
wb.recalculate();
const sample=await wb.inspect({kind:'table',range:'\'Boss01 fields\'!A1:L5',include:'values',tableMaxRows:5,tableMaxCols:12,maxChars:2400});
console.log(sample.ndjson);
const values=sheet.getRangeByIndexes(0,0,matrix.length,headers.length).values;
if(values.length!==rows.length+1||new Set(values.slice(1).map(r=>r[0])).size!==rows.length)throw Error('row integrity');
const csv=values.map(row=>row.map(v=>'"'+String(v??'').replaceAll('"','""')+'"').join(',')).join('\r\n')+'\r\n';
await fs.writeFile(out+'/WP13_BOSS01_FIELD_MANIFEST.csv',csv);
const round=await Workbook.fromCSV(await fs.readFile(out+'/WP13_BOSS01_FIELD_MANIFEST.csv','utf8'),{sheetName:'Check'});
if(round.worksheets.getItem('Check').getRangeByIndexes(0,0,matrix.length,12).values.length!==matrix.length)throw Error('CSV readback');
try{const preview=await wb.render({sheetName:'Boss01 fields',range:'A1:E6',scale:1,format:'png'});await fs.writeFile(out+'/WP6Support/manifest_preview.png',new Uint8Array(await preview.arrayBuffer()));}catch(e){console.log('PREVIEW_UNAVAILABLE '+e.message);}
const counts=Object.fromEntries(['HYDRATABLE_NOW','NEEDS_SEAM','NEEDS_EDITOR'].map(c=>[c,rows.filter(r=>r[9]===c).length]));
const stats={rows:rows.length,counts,nativeFiles:native.length,exportFiles:packNames.length,propertyRows:rows.filter(r=>r[6]==='CXX_PROPERTY_DEFAULT'||r[6]==='ASSET_REFERENCE_DEFAULT'&&!r[4].includes('_')).length,pins};
await fs.writeFile(out+'/WP6Support/manifest_inventory.json',JSON.stringify(stats,null,2));
console.log(JSON.stringify({rows:rows.length,counts,nativeFiles:native.length,exportFiles:packNames.length,csvSHA256:sha(csv)}));
