// Mechanical patch packaging only. Never writes live Source or Scripts.
import fs from 'node:fs/promises';
import crypto from 'node:crypto';
const codex='Docs/BossCombatReview/Execution/Codex',draft=codex+'/Drafts/';
const step2=['Source/OneBossFight/Player/RPGEncounterBinding.h','Source/OneBossFight/Player/RPGEncounterBinding.cpp','Source/OneBossFight/Tests/RPGEncounterBindingTests.cpp'];
const step3=['Source/OneBossFight/Boss/RPGTimelineCompiler.h','Source/OneBossFight/Boss/RPGTimelineCompiler.cpp','Source/OneBossFight/Boss/RPGShadowCompare.h','Source/OneBossFight/Boss/RPGShadowCompare.cpp','Source/OneBossFight/Tests/RPGTimelineTests.cpp'];
const sha=s=>crypto.createHash('sha256').update(s).digest('hex');
const lines=s=>s.replaceAll('\r\n','\n').trimEnd().split('\n');
function newfile(p,s){const ls=lines(s);return`diff --git a/${p} b/${p}\nnew file mode 100644\n--- /dev/null\n+++ b/${p}\n@@ -0,0 +1,${ls.length} @@\n`+ls.map(l=>'+'+l).join('\n')+'\n';}
function replace(p,before,after){
 const a=lines(before),b=lines(after);let i=0,j=0;const changes=[];
 while(i<a.length||j<b.length){
  if(a[i]===b[j]){i++;j++;continue;}
  const start=j;while(j<b.length&&b[j]!==a[i])j++;
  if(j===b.length)throw Error('Only insertions permitted in tracker seam');
  changes.push({old:i,added:b.slice(start,j)});
 }
 let offset=0,result=`diff --git a/${p} b/${p}\n--- a/${p}\n+++ b/${p}\n`;
 for(const c of changes){const start=Math.max(0,c.old-3),end=Math.min(a.length,c.old+3),count=end-start;
  result+=`@@ -${start+1},${count} +${start+offset+1},${count+c.added.length} @@\n`;
  result+=a.slice(start,c.old).map(l=>' '+l).join('\n')+'\n';
  result+=c.added.map(l=>'+'+l).join('\n')+'\n';
  result+=a.slice(c.old,end).map(l=>' '+l).join('\n')+'\n';offset+=c.added.length;
 }return result;
}
let p2='',p3='';const pins=[];
for(const [which,paths]of[[2,step2],[3,step3]])for(const p of paths){const s=await fs.readFile(draft+p,'utf8');pins.push({file:p,stagedSHA256:sha(s),kind:'new'});if(which===2)p2+=newfile(p,s);else p3+=newfile(p,s);}
for(const suffix of ['h','cpp']){
 const p='Source/OneBossFight/Player/RPGAttackTracker.'+suffix,before=await fs.readFile(p,'utf8');let after=before.replaceAll('\r\n','\n');
 if(suffix==='h'){
  after=after.replace('#include "RPGAttackTracker.generated.h"','#include "Boss/RPGShadowCompare.h"\n#include "RPGAttackTracker.generated.h"');
  after=after.replace('\tURPGAttackTracker();','\tURPGAttackTracker();\n#if !UE_BUILD_SHIPPING\n\tRPGTimeline::FAfterTracker OnAfterObservation;\n\tbool bObservationBroadcastInProgress = false;\n#endif');
 }else{
  after=after.replace('#include "Player/RPGAttackTracker.h"','#include "Player/RPGAttackTracker.h"\n#include "Misc/ScopeExit.h"\n#include "Templates/UnrealTemplate.h"');
  const anchor='\tSuper::TickComponent(DeltaTime, TickType, ThisTickFunction);';
  if(after.split(anchor).length!==2)throw Error('tick anchor drift');
  after=after.replace(anchor,anchor+'\n#if !UE_BUILD_SHIPPING\n\tON_SCOPE_EXIT\n\t{\n\t\tif (IsValid(this) && !bObservationBroadcastInProgress && OnAfterObservation.IsBound())\n\t\t{\n\t\t\tTGuardValue<bool> BroadcastGuard(bObservationBroadcastInProgress, true);\n\t\t\tconst RPGTimeline::FPassiveSnapshot Sample = RPGTimeline::CaptureAfterTracker(*this);\n\t\t\tOnAfterObservation.Broadcast(Sample);\n\t\t}\n\t};\n#endif');
 }
 if(after===before)throw Error('anchor drift '+p);
 const withOriginalEOL=before.includes('\r\n')?after.replaceAll('\n','\r\n'):after;
 pins.push({file:p,preimageSHA256:sha(before),postimageSHA256:sha(withOriginalEOL),kind:'tracker observation only; context insertions, original EOL retained'});p3+=replace(p,before,after);
}
await fs.writeFile(codex+'/PROMOTION_STEP2_SCAFFOLD.patch',p2);
await fs.writeFile(codex+'/PROMOTION_STEP3_SCAFFOLD.patch',p3);
await fs.writeFile(codex+'/WP6Support/promotion_pins.json',JSON.stringify({scope:'SCAFFOLD ONLY; production hydration/importer absent; NOT AUTHORISED TO APPLY',files:pins},null,2));
console.log(JSON.stringify({step2Files:step2.length,step3Files:step3.length+2,step2SHA256:sha(p2),step3SHA256:sha(p3)}));
