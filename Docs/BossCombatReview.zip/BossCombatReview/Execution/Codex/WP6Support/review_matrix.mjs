import fs from 'node:fs/promises';
import { Workbook } from '@oai/artifact-tool';
const path = new URL('../D10_IMPLEMENTATION_MATRIX.csv', import.meta.url);
const text = await fs.readFile(path, 'utf8');
const wb = await Workbook.fromCSV(text, { sheetName: 'Implementation' });
const sheet = wb.worksheets.getItem('Implementation');
const before = sheet.getRange('A1:I84').values;
if (before.length !== 84 || new Set(before.slice(1).map(r => r[0])).size !== 83) throw Error('83 unique rows required');
const def = before.findIndex(r => r[0] === 'BOSS-DEF-005');
const awr = before.findIndex(r => r[0] === 'BOSS-AWR-008');
if (def < 1 || awr < 1) throw Error('target rows missing');
const edit = process.argv.includes('--edit');
sheet.getRange(`E${def+1}`).format.columnWidth = 49; // ephemeral preview only; CSV has no formatting
if (edit) {
  sheet.getRange(`E${def+1}`).values = [['P3 mechanism; P6 decision']];
  const suffix = '; P3 proves defense states/resolver outcomes; P6 proves delayed, budgeted observable-cue AI choices';
  for (const col of ['G','H']) sheet.getRange(`${col}${def+1}`).values = [[before[def][col === 'G' ? 6 : 7] + suffix]];
  const cue = '; debug-off capture ties observable cue timing to changed action, readable failure and punish opportunity';
  for (const col of ['G','H']) sheet.getRange(`${col}${awr+1}`).values = [[before[awr][col === 'G' ? 6 : 7] + cue]];
}
wb.recalculate();
const after = sheet.getRange('A1:I84').values;
const changes = [];
for (let r=0;r<84;r++) for(let c=0;c<9;c++) if(before[r][c] !== after[r][c]) changes.push([r,c]);
if (edit && (changes.length !== 5 || changes.some(([r,c]) => !((r===def && [4,6,7].includes(c)) || (r===awr && [6,7].includes(c)))))) throw Error('scope changed');
const preview = await wb.render({sheetName:'Implementation',range:`E${def+1}:E${def+1}`,scale:1,format:'png'});
await fs.writeFile(new URL(edit ? 'phase_after.png' : 'phase_before.png', import.meta.url), new Uint8Array(await preview.arrayBuffer()));
console.log(JSON.stringify({edit,changes,defRow:def+1,awrRow:awr+1,rows:edit?[after[awr],after[def]]:[],csv:edit?[after[awr],after[def]].map(row=>row.map(value=>'"'+String(value).replaceAll('"','""')+'"').join(',')):[]}));
